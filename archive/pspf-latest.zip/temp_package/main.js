// PSPF Explorer - Main JavaScript Application
// Core data models, navigation, and business logic

class PSPFExplorer {
    constructor() {
        this.data = this.loadData();
        this.currentView = 'home';
        this.selectedDomain = null;
        this.selectedRequirement = null;
        this.init();
    }

    init() {
        this.render();
        this.setupEventListeners();
        
        // Use requestAnimationFrame for better performance
        requestAnimationFrame(() => {
            this.showWelcomeModalIfFirstTime();
        });
    }

    // Data Management
    loadData() {
        try {
            // Load user data from localStorage
            this.projects = JSON.parse(localStorage.getItem('pspf_projects') || '[]');
            this.tasks = JSON.parse(localStorage.getItem('pspf_tasks') || '[]');
            this.risks = JSON.parse(localStorage.getItem('pspf_risks') || '[]');
            this.incidents = JSON.parse(localStorage.getItem('pspf_incidents') || '[]');
            this.compliance = JSON.parse(localStorage.getItem('pspf_compliance') || '{}');
            
            // Load static PSPF data
            this.loadPSPFData();
        } catch (error) {
            console.error('Error loading data:', error);
            this.showError('Failed to load data. Please refresh the page.');
        }
    }

    saveData() {
        try {
            localStorage.setItem('pspf_projects', JSON.stringify(this.projects));
            localStorage.setItem('pspf_tasks', JSON.stringify(this.tasks));
            localStorage.setItem('pspf_risks', JSON.stringify(this.risks));
            localStorage.setItem('pspf_incidents', JSON.stringify(this.incidents));
            localStorage.setItem('pspf_compliance', JSON.stringify(this.compliance));
        } catch (error) {
            console.error('Error saving data:', error);
            this.showError('Failed to save data. Your changes may be lost.');
        }
    }

    loadPSPFData() {
        // PSPF 2025 - The six security domains
        this.domains = [
            {
                id: 'governance',
                title: 'Governance',
                description: 'Strategic leadership, CSO/CISO appointment, governance accountability and reporting',
                requirements: ['gov-1', 'gov-2', 'gov-3', 'gov-4']
            },
            {
                id: 'risk',
                title: 'Risk',
                description: 'Security risk management, third-party risks, and foreign interference mitigation',
                requirements: ['risk-1', 'risk-2', 'risk-3', 'risk-4']
            },
            {
                id: 'information',
                title: 'Information',
                description: 'Protective markings, classifications, need-to-know principle and secure handling',
                requirements: ['info-1', 'info-2', 'info-3', 'info-4', 'info-5']
            },
            {
                id: 'technology',
                title: 'Technology',
                description: 'Cybersecurity strategy, Essential Eight, AI/quantum tech, and zero trust culture',
                requirements: ['tech-1', 'tech-2', 'tech-3', 'tech-4', 'tech-5']
            },
            {
                id: 'personnel',
                title: 'Personnel',
                description: 'Security clearances, pre-employment screening and ongoing suitability checks',
                requirements: ['pers-1', 'pers-2', 'pers-3', 'pers-4', 'pers-5']
            },
            {
                id: 'physical',
                title: 'Physical',
                description: 'Security zones, facility certification, access controls and asset disposal',
                requirements: ['phys-1', 'phys-2', 'phys-3', 'phys-4', 'phys-5']
            }
        ];

        this.requirements = {
            // Governance domain requirements
            'gov-1': {
                id: 'gov-1',
                domainId: 'governance',
                title: 'Chief Security Officer',
                description: 'Entities must have a Chief Security Officer or equivalent senior executive responsible for protective security.',
                guidance: 'Appoint a senior executive to oversee all protective security matters and ensure appropriate governance structures are in place.'
            },
            'gov-2': {
                id: 'gov-2',
                domainId: 'governance',
                title: 'Chief Information Security Officer',
                description: 'Entities must appoint a CISO to oversee cyber security with explicit reporting to Audit Committees.',
                guidance: 'Appoint a qualified CISO with appropriate authority and resources to manage cybersecurity across the organization.'
            },
            'gov-3': {
                id: 'gov-3',
                domainId: 'governance',
                title: 'Annual Compliance Reporting',
                description: 'Entities must provide annual compliance reporting to Ministers and Department of Home Affairs.',
                guidance: 'Establish regular reporting cycles to keep senior leadership informed of security posture and compliance status.'
            },
            'gov-4': {
                id: 'gov-4',
                domainId: 'governance',
                title: 'Security Governance Framework',
                description: 'Entities must establish governance accountability, reporting structures and defined roles/responsibilities.',
                guidance: 'Implement clear governance structures with defined roles, responsibilities, and accountability mechanisms.'
            },

            // Risk domain requirements  
            'risk-1': {
                id: 'risk-1',
                domainId: 'risk',
                title: 'Security Risk Management',
                description: 'Entities must implement security risk management processes aligned with enterprise risk frameworks.',
                guidance: 'Integrate security risk management into enterprise risk processes with clear risk tolerance statements.'
            },
            'risk-2': {
                id: 'risk-2',
                domainId: 'risk',
                title: 'Third-Party Risk Management',
                description: 'Entities must manage third-party and supply chain security risks effectively.',
                guidance: 'Assess and monitor security risks from third-party relationships and supply chain dependencies.'
            },
            'risk-3': {
                id: 'risk-3',
                domainId: 'risk',
                title: 'Foreign Interference Mitigation',
                description: 'Entities must implement measures to identify and mitigate foreign interference risks.',
                guidance: 'Develop capabilities to detect and respond to foreign interference attempts across all domains.'
            },
            'risk-4': {
                id: 'risk-4',
                domainId: 'risk',
                title: 'Risk Documentation and Sharing',
                description: 'Entities must document risk tolerance, ownership, and share identified risks appropriately.',
                guidance: 'Maintain comprehensive risk registers and share threat intelligence with relevant stakeholders.'
            },
            
            // Information domain requirements
            'info-1': {
                id: 'info-1',
                domainId: 'information',
                title: 'Protective Markings and Classifications',
                description: 'Entities must apply protective markings using OFFICIAL, PROTECTED, SECRET, TOP SECRET classifications.',
                guidance: 'Implement consistent classification and marking systems following Australian Government standards.'
            },
            'info-2': {
                id: 'info-2',
                domainId: 'information',
                title: 'Need-to-Know Principle',
                description: 'Entities must implement need-to-know principles and secure handling requirements.',
                guidance: 'Restrict information access based on legitimate business need and implement appropriate handling controls.'
            },
            'info-3': {
                id: 'info-3',
                domainId: 'information',
                title: 'Recordkeeping Standards',
                description: 'Entities must implement recordkeeping standards and secure information sharing protocols.',
                guidance: 'Maintain records in accordance with government standards and implement secure sharing mechanisms.'
            },
            'info-4': {
                id: 'info-4',
                domainId: 'information',
                title: 'Information Handling Procedures',
                description: 'Entities must establish comprehensive information handling and disposal protocols.',
                guidance: 'Create detailed procedures covering creation, transmission, storage, and secure disposal of information.'
            },
            'info-5': {
                id: 'info-5',
                domainId: 'information',
                title: 'Information Security Controls',
                description: 'Entities must implement technical and administrative controls to protect information assets.',
                guidance: 'Deploy layered security controls including encryption, access controls, and monitoring systems.'
            },

            // Technology domain requirements
            'tech-1': {
                id: 'tech-1',
                domainId: 'technology',
                title: 'Cybersecurity Strategy and Zero Trust',
                description: 'Entities must establish a cybersecurity strategy with zero trust culture and uplift plans.',
                guidance: 'Develop comprehensive cybersecurity strategy embracing zero trust principles and continuous improvement.'
            },
            'tech-2': {
                id: 'tech-2',
                domainId: 'technology',
                title: 'Essential Eight Implementation',
                description: 'Entities must implement Essential Eight mitigation strategies and ongoing cyber threat intelligence sharing.',
                guidance: 'Deploy all Essential Eight controls at appropriate maturity levels and participate in threat intelligence programs.'
            },
            'tech-3': {
                id: 'tech-3',
                domainId: 'technology',
                title: 'Emerging Technology Management',
                description: 'Entities must implement policies for AI, quantum computing, and connected devices.',
                guidance: 'Establish governance and security controls for emerging technologies including AI and quantum systems.'
            },
            'tech-4': {
                id: 'tech-4',
                domainId: 'technology',
                title: 'Cloud and Infrastructure Certification',
                description: 'Entities must use certified cloud/data centre providers under Australian Government Hosting Certification Framework.',
                guidance: 'Only use government-certified hosting providers for classified and government significant systems.'
            },
            'tech-5': {
                id: 'tech-5',
                domainId: 'technology',
                title: 'Gateway and Security Assessment',
                description: 'Entities must conduct security assessment and authorisation for technology assets with gateway protections.',
                guidance: 'Implement mandatory security assessments and deploy Security Service Edge protections for digital infrastructure.'
            },
            
            // Personnel domain requirements
            'pers-1': {
                id: 'pers-1',
                domainId: 'personnel',
                title: 'Pre-employment Screening',
                description: 'Entities must conduct pre-employment screening and ongoing suitability checks for all personnel.',
                guidance: 'Implement risk-based screening procedures proportionate to access requirements and review regularly.'
            },
            'pers-2': {
                id: 'pers-2',
                domainId: 'personnel',
                title: 'Security Clearance Management',
                description: 'Entities must manage security clearance processes and conditional clearance appropriately.',
                guidance: 'Maintain accurate clearance records, ensure timely renewals, and manage conditional access appropriately.'
            },
            'pers-3': {
                id: 'pers-3',
                domainId: 'personnel',
                title: 'Staff Vetting and Eligibility',
                description: 'Entities must implement staff vetting processes and manage eligibility waivers appropriately.',
                guidance: 'Conduct thorough vetting aligned with access requirements and strictly control eligibility waiver usage.'
            },
            'pers-4': {
                id: 'pers-4',
                domainId: 'personnel',
                title: 'Temporary and Remote Access',
                description: 'Entities must implement controls for temporary access and remote working arrangements.',
                guidance: 'Establish secure procedures for temporary access grants and remote work security requirements.'
            },
            'pers-5': {
                id: 'pers-5',
                domainId: 'personnel',
                title: 'Ongoing Suitability Assessment',
                description: 'Entities must conduct continuous suitability monitoring and insider threat detection.',
                guidance: 'Implement ongoing monitoring capabilities and procedures to assess continued personnel suitability.'
            },
            
            // Physical domain requirements
            'phys-1': {
                id: 'phys-1',
                domainId: 'physical',
                title: 'Security Zones and Planning',
                description: 'Entities must implement security planning and zone requirements for entity facilities.',
                guidance: 'Establish appropriate security zones with defined access controls and protection measures.'
            },
            'phys-2': {
                id: 'phys-2',
                domainId: 'physical',
                title: 'Facility Certification and Accreditation',
                description: 'Entities must ensure certification, accreditation, and mandatory controls for physical assets and premises.',
                guidance: 'Obtain appropriate certifications for facilities handling classified material and maintain accreditation.'
            },
            'phys-3': {
                id: 'phys-3',
                domainId: 'physical',
                title: 'Access Controls and Monitoring',
                description: 'Entities must implement controls on access, technical surveillance, and monitoring systems.',
                guidance: 'Deploy appropriate surveillance systems and access monitoring proportionate to security requirements.'
            },
            'phys-4': {
                id: 'phys-4',
                domainId: 'physical',
                title: 'Asset Protection and Disposal',
                description: 'Entities must implement controls for asset protection and secure disposal procedures.',
                guidance: 'Establish procedures for protecting physical assets and secure disposal of sensitive materials.'
            },
            'phys-5': {
                id: 'phys-5',
                domainId: 'physical',
                title: 'Mandatory Physical Controls',
                description: 'Entities must implement mandatory controls for physical premises and infrastructure.',
                guidance: 'Deploy comprehensive physical security controls appropriate to the facility security classification.'
            }
        };
    }

    // Health Assessment Logic
    calculateDomainHealth(domainId) {
        const domain = this.domains.find(d => d.id === domainId);
        if (!domain) return 'critical';

        const requirements = domain.requirements;
        let totalRequirements = requirements.length;
        let metRequirements = 0;
        let wellDocumentedNotMet = 0;
        let poorlyDocumentedNotMet = 0;

        requirements.forEach(reqId => {
            const compliance = this.compliance[reqId];
            if (compliance) {
                if (compliance.met) {
                    metRequirements++;
                } else {
                    // Check comment quality for not-met requirements
                    const comment = compliance.comment || '';
                    if (comment.length > 50) { // Well documented
                        wellDocumentedNotMet++;
                    } else {
                        poorlyDocumentedNotMet++;
                    }
                }
            } else {
                poorlyDocumentedNotMet++; // No compliance data = poorly documented
            }
        });

        // Health calculation based on requirements
        if (metRequirements === totalRequirements) {
            return 'healthy'; // All requirements met
        } else if (poorlyDocumentedNotMet === 0 && wellDocumentedNotMet > 0) {
            return 'warning'; // Some not met but all well documented
        } else {
            return 'critical'; // Poor documentation or no progress
        }
    }

    calculateOverallCompliance() {
        let totalRequirements = 0;
        let metRequirements = 0;

        this.domains.forEach(domain => {
            domain.requirements.forEach(reqId => {
                totalRequirements++;
                if (this.compliance[reqId] && this.compliance[reqId].met) {
                    metRequirements++;
                }
            });
        });

        return totalRequirements > 0 ? Math.round((metRequirements / totalRequirements) * 100) : 0;
    }

    // First Time User Experience
    checkFirstTime() {
        const hasVisited = localStorage.getItem('pspf_has_visited');
        if (!hasVisited) {
            this.showWelcomeModal();
            localStorage.setItem('pspf_has_visited', 'true');
        }
    }

    showWelcomeModal() {
        const modal = document.getElementById('welcomeModal');
        modal.classList.add('active');
    }

    hideWelcomeModal() {
        const modal = document.getElementById('welcomeModal');
        modal.classList.remove('active');
    }

    showWelcomeModalIfFirstTime() {
        // Check if user has seen the welcome modal before
        const hasSeenWelcome = localStorage.getItem('pspf_welcome_seen');
        if (!hasSeenWelcome) {
            this.showWelcomeModal();
            // Mark as seen when they close it (handled in the close button event listener)
        }
    }

    // Navigation
    navigateTo(view, context = {}) {
        this.currentView = view;
        
        // Update current context
        if (context.domainId) this.currentDomain = context.domainId;
        if (context.requirementId) this.currentRequirement = context.requirementId;
        if (context.projectId) this.currentProject = context.projectId;
        
        // Update breadcrumb
        this.updateBreadcrumb(view, context);
        
        // Render new view
        this.render();
    }

    updateBreadcrumb(view, context) {
        this.breadcrumb = ['home'];
        
        if (view === 'domain' && context.domainId) {
            const domain = this.domains.find(d => d.id === context.domainId);
            this.breadcrumb.push({ type: 'domain', id: context.domainId, title: domain.title });
        }
        
        if (view === 'requirement' && context.requirementId) {
            const domain = this.domains.find(d => d.id === context.domainId);
            const requirement = this.requirements[context.requirementId];
            this.breadcrumb.push(
                { type: 'domain', id: context.domainId, title: domain.title },
                { type: 'requirement', id: context.requirementId, title: requirement.title }
            );
        }
        
        if (view === 'project' && context.projectId) {
            const project = this.projects.find(p => p.id === context.projectId);
            const requirement = this.requirements[context.requirementId];
            const domain = this.domains.find(d => d.id === context.domainId);
            this.breadcrumb.push(
                { type: 'domain', id: context.domainId, title: domain.title },
                { type: 'requirement', id: context.requirementId, title: requirement.title },
                { type: 'project', id: context.projectId, title: project.name }
            );
        }
        
        this.renderBreadcrumb();
    }

    renderBreadcrumb() {
        const breadcrumbEl = document.getElementById('breadcrumb');
        breadcrumbEl.innerHTML = '';
        
        this.breadcrumb.forEach((item, index) => {
            const link = document.createElement('a');
            link.href = '#';
            
            if (typeof item === 'string') {
                link.textContent = 'PSPF Domains';
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    this.navigateTo('home');
                });
            } else {
                link.textContent = item.title;
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    if (item.type === 'domain') {
                        this.navigateTo('domain', { domainId: item.id });
                    } else if (item.type === 'requirement') {
                        this.navigateTo('requirement', { 
                            domainId: this.currentDomain, 
                            requirementId: item.id 
                        });
                    } else if (item.type === 'project') {
                        this.navigateTo('project', { 
                            domainId: this.currentDomain,
                            requirementId: this.currentRequirement,
                            projectId: item.id 
                        });
                    }
                });
            }
            
            breadcrumbEl.appendChild(link);
        });
    }

    // Event Listeners
    setupEventListeners() {
        // Navigation buttons
        document.getElementById('homeBtn').addEventListener('click', () => {
            this.navigateTo('home');
            this.updateNavButtons('homeBtn');
        });
        
        document.getElementById('searchBtn').addEventListener('click', () => {
            this.navigateTo('search');
            this.updateNavButtons('searchBtn');
        });
        
        document.getElementById('progressBtn').addEventListener('click', () => {
            this.navigateTo('progress');
            this.updateNavButtons('progressBtn');
        });

        document.getElementById('dataBtn').addEventListener('click', () => {
            this.navigateTo('data');
            this.updateNavButtons('dataBtn');
        });
        
        document.getElementById('helpBtn').addEventListener('click', () => {
            this.showWelcomeModal();
        });

        // Welcome modal
        document.getElementById('closeWelcome').addEventListener('click', () => {
            this.hideWelcomeModal();
            // Mark welcome as seen so it doesn't show again
            localStorage.setItem('pspf_welcome_seen', 'true');
        });

        // Modal close on backdrop click
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    modal.classList.remove('active');
                }
            });
        });

        // Tab switching and global action handlers
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('tab-btn')) {
                this.switchTab(e.target);
                return;
            }
            
            // Handle data-action buttons
            if (e.target.dataset.action) {
                const action = e.target.dataset.action;
                const id = e.target.dataset.id;
                
                switch (action) {
                    case 'edit-project':
                        this.showProjectModal(id);
                        break;
                    case 'delete-project':
                        this.deleteProject(id);
                        break;
                    case 'edit-task':
                        this.showTaskModal(id);
                        break;
                    case 'delete-task':
                        this.deleteTask(id);
                        break;
                    case 'edit-risk':
                        this.showRiskModal(id);
                        break;
                    case 'delete-risk':
                        this.deleteRisk(id);
                        break;
                    case 'edit-incident':
                        this.showIncidentModal(id);
                        break;
                    case 'delete-incident':
                        this.deleteIncident(id);
                        break;
                }
                e.preventDefault();
                e.stopPropagation();
            }
        });

        // CRUD button event listeners
        this.setupCRUDEventListeners();
    }

    setupCRUDEventListeners() {
        // Project CRUD
        const addProjectBtn = document.getElementById('addProjectBtn');
        if (addProjectBtn) {
            addProjectBtn.addEventListener('click', () => this.showProjectModal());
        }

        const projectForm = document.getElementById('projectForm');
        if (projectForm) {
            projectForm.addEventListener('submit', (e) => this.handleProjectSubmit(e));
        }

        const cancelProjectBtn = document.getElementById('cancelProject');
        if (cancelProjectBtn) {
            cancelProjectBtn.addEventListener('click', () => this.hideModal('projectModal'));
        }

        // Task CRUD
        const addTaskBtn = document.getElementById('addTaskBtn');
        if (addTaskBtn) {
            addTaskBtn.addEventListener('click', () => this.showTaskModal());
        }

        const taskForm = document.getElementById('taskForm');
        if (taskForm) {
            taskForm.addEventListener('submit', (e) => this.handleTaskSubmit(e));
        }

        const cancelTaskBtn = document.getElementById('cancelTask');
        if (cancelTaskBtn) {
            cancelTaskBtn.addEventListener('click', () => this.hideModal('taskModal'));
        }

        // Risk CRUD
        const addRiskBtn = document.getElementById('addRiskBtn');
        if (addRiskBtn) {
            addRiskBtn.addEventListener('click', () => this.showRiskModal());
        }

        const riskForm = document.getElementById('riskForm');
        if (riskForm) {
            riskForm.addEventListener('submit', (e) => this.handleRiskSubmit(e));
        }

        const cancelRiskBtn = document.getElementById('cancelRisk');
        if (cancelRiskBtn) {
            cancelRiskBtn.addEventListener('click', () => this.hideModal('riskModal'));
        }

        // Incident CRUD
        const addIncidentBtn = document.getElementById('addIncidentBtn');
        if (addIncidentBtn) {
            addIncidentBtn.addEventListener('click', () => this.showIncidentModal());
        }

        const incidentForm = document.getElementById('incidentForm');
        if (incidentForm) {
            incidentForm.addEventListener('submit', (e) => this.handleIncidentSubmit(e));
        }

        const cancelIncidentBtn = document.getElementById('cancelIncident');
        if (cancelIncidentBtn) {
            cancelIncidentBtn.addEventListener('click', () => this.hideModal('incidentModal'));
        }

        // Data management event listeners
        const exportDataBtn = document.getElementById('exportDataBtn');
        if (exportDataBtn) {
            exportDataBtn.addEventListener('click', () => this.exportData());
        }

        const importDataBtn = document.getElementById('importDataBtn');
        const importFileInput = document.getElementById('importFileInput');
        if (importDataBtn && importFileInput) {
            importDataBtn.addEventListener('click', () => importFileInput.click());
            importFileInput.addEventListener('change', (e) => this.importData(e));
        }

        const clearDataBtn = document.getElementById('clearDataBtn');
        if (clearDataBtn) {
            clearDataBtn.addEventListener('click', () => this.clearAllData());
        }
    }

    updateNavButtons(activeId) {
        document.querySelectorAll('.nav-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        document.getElementById(activeId).classList.add('active');
    }

    switchTab(button) {
        const tabName = button.dataset.tab;
        const tabContainer = button.closest('.content-tabs');
        
        // Update tab buttons
        tabContainer.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        button.classList.add('active');
        
        // Update tab panes
        tabContainer.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
        });
        const targetPane = tabContainer.querySelector(`#${tabName}Tab`);
        if (targetPane) {
            targetPane.classList.add('active');
        }
    }

    // Rendering
    render() {
        // Hide all views
        document.querySelectorAll('.view').forEach(view => {
            view.classList.remove('active');
        });
        
        // Show current view
        const currentViewEl = document.getElementById(`${this.currentView}View`);
        if (currentViewEl) {
            currentViewEl.classList.add('active');
        }
        
        // Render specific view content
        switch (this.currentView) {
            case 'home':
                this.renderHome();
                break;
            case 'domain':
                this.renderDomain();
                break;
            case 'requirement':
                this.renderRequirement();
                break;
            case 'project':
                this.renderProject();
                break;
            case 'search':
                this.renderSearch();
                break;
            case 'progress':
                this.renderProgress();
                break;
            case 'data':
                this.renderDataManagement();
                break;
        }
    }

    renderHome() {
        this.renderDomainsGrid();
        this.renderStatsOverview();
    }

    renderDomainsGrid() {
        const grid = document.getElementById('domainsGrid');
        grid.innerHTML = '';
        
        this.domains.forEach(domain => {
            const health = this.calculateDomainHealth(domain.id);
            const projectCount = this.projects.filter(p => 
                domain.requirements.includes(p.requirementId)
            ).length;
            
            const card = document.createElement('div');
            card.className = 'domain-card';
            card.title = domain.description; // Add tooltip with description
            card.innerHTML = `
                <div class="domain-card-header">
                    <div class="pulse-dot domain-pulse ${health}"></div>
                    <h3 class="domain-title">${domain.title}</h3>
                </div>
                <div class="domain-stats">
                    <span class="domain-compliance">${domain.requirements.length} requirements • ${projectCount} projects</span>
                </div>
            `;
            
            card.addEventListener('click', () => {
                this.showDomainRequirements(domain.id);
            });
            
            grid.appendChild(card);
        });
    }

    renderStatsOverview() {
        const totalProjects = this.projects.length;
        const totalTasks = this.tasks.length;
        const completedTasks = this.tasks.filter(t => t.status === 'completed').length;
        const overallCompliance = this.calculateOverallCompliance();
        
        document.getElementById('totalProjects').textContent = totalProjects;
        document.getElementById('totalTasks').textContent = totalTasks;
        document.getElementById('completedTasks').textContent = completedTasks;
        document.getElementById('overallCompliance').textContent = `${overallCompliance}%`;
    }

    renderDomain() {
        const domain = this.domains.find(d => d.id === this.currentDomain);
        if (!domain) return;
        
        document.getElementById('domainTitle').textContent = domain.title;
        document.getElementById('domainDescription').textContent = domain.description;
        
        // Update domain health indicator
        const health = this.calculateDomainHealth(domain.id);
        const pulseEl = document.getElementById('domainPulse');
        pulseEl.className = `pulse-dot ${health}`;
        
        const healthTexts = {
            healthy: 'Excellent health - all requirements met',
            warning: 'Good health - some requirements need attention but well documented',
            critical: 'Needs attention - requirements not met or poorly documented'
        };
        document.getElementById('domainHealthText').textContent = healthTexts[health];
        
        this.renderRequirementsList();
    }

    renderRequirementsList() {
        const domain = this.domains.find(d => d.id === this.currentDomain);
        const list = document.getElementById('requirementsList');
        list.innerHTML = '';
        
        domain.requirements.forEach(reqId => {
            const req = this.requirements[reqId];
            const compliance = this.compliance[reqId];
            const status = compliance?.met ? 'met' : 'not-met';
            
            const card = document.createElement('div');
            card.className = `requirement-card ${status}`;
            card.innerHTML = `
                <div class="requirement-header">
                    <h4 class="requirement-title">${req.title}</h4>
                    <span class="requirement-status ${status}">
                        ${status === 'met' ? 'Met' : 'Not Met'}
                    </span>
                </div>
                <p class="requirement-description">${req.description}</p>
            `;
            
            card.addEventListener('click', () => {
                this.navigateTo('requirement', { 
                    domainId: this.currentDomain, 
                    requirementId: reqId 
                });
            });
            
            list.appendChild(card);
        });
    }

    renderRequirement() {
        const req = this.requirements[this.currentRequirement];
        if (!req) return;
        
        document.getElementById('requirementTitle').textContent = req.title;
        document.getElementById('requirementDescription').textContent = req.description;
        
        // Render guidance content
        document.getElementById('guidanceContent').innerHTML = `
            <div class="guidance-card">
                <h4>Implementation Guidance</h4>
                <p>${req.guidance}</p>
            </div>
        `;
        
        this.renderProjectsList();
        
        this.renderProjectsList();
    }

    renderProjectsList() {
        const list = document.getElementById('projectsList');
        const projects = this.projects.filter(p => p.requirementId === this.currentRequirement);
        
        list.innerHTML = '';
        
        if (projects.length === 0) {
            list.innerHTML = '<p>No projects yet. Add a project to start tracking work for this requirement.</p>';
        } else {
            projects.forEach(project => {
                const card = document.createElement('div');
                card.className = 'list-item';
                card.innerHTML = `
                    <div class="list-item-header">
                        <h5 class="list-item-title">${project.name}</h5>
                        <div class="list-item-actions">
                            ${project.url ? `<a href="${project.url}" target="_blank" class="btn btn-link" title="Open project URL">🔗</a>` : ''}
                            <button class="btn btn-secondary" data-action="edit-project" data-id="${project.id}">Edit</button>
                            <button class="btn btn-secondary" data-action="delete-project" data-id="${project.id}">Delete</button>
                        </div>
                    </div>
                    <p>${project.description}</p>
                    <div class="list-item-meta">
                        <span class="status-badge ${project.status}">${project.status}</span>
                        <span>Start: ${project.startDate || 'Not set'}</span>
                        <span>End: ${project.endDate || 'Not set'}</span>
                        ${project.url ? `<span class="project-url">URL: <a href="${project.url}" target="_blank">${project.url}</a></span>` : ''}
                    </div>
                `;
                
                card.addEventListener('click', (e) => {
                    if (!e.target.closest('.list-item-actions')) {
                        this.navigateTo('project', {
                            domainId: this.currentDomain,
                            requirementId: this.currentRequirement,
                            projectId: project.id
                        });
                    }
                });
                
                list.appendChild(card);
            });
        }
    }

    showDomainRequirements(domainId) {
        const domain = this.domains.find(d => d.id === domainId);
        if (!domain) return;

        // Update the requirements section header
        document.getElementById('selectedDomainTitle').textContent = `${domain.title} Requirements`;
        document.getElementById('selectedDomainDescription').textContent = domain.description;

        // Show the requirements section
        const requirementsSection = document.getElementById('requirementsSection');
        requirementsSection.classList.remove('hidden');

        // Render the requirements grid
        this.renderRequirementsGrid(domain);

        // Scroll to requirements section
        requirementsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    renderRequirementsGrid(domain) {
        const grid = document.getElementById('requirementsGrid');
        grid.innerHTML = '';

        domain.requirements.forEach(reqId => {
            const req = this.requirements[reqId];
            const compliance = this.compliance[reqId];
            const status = compliance?.met ? 'met' : 'not-met';
            
            // Get project and task counts for this requirement
            const projects = this.projects.filter(p => p.requirementId === reqId);
            const allTasks = projects.flatMap(p => this.tasks.filter(t => t.projectId === p.id));
            const completedTasks = allTasks.filter(t => t.status === 'completed');
            
            const card = document.createElement('div');
            card.className = `requirement-card ${status}`;
            card.innerHTML = `
                <div class="requirement-header">
                    <h4 class="requirement-title">${req.title}</h4>
                    <span class="requirement-status ${status}">
                        ${status === 'met' ? '✓ Met' : '✗ Not Met'}
                    </span>
                </div>
                <p class="requirement-description">${req.description}</p>
                <div class="requirement-stats">
                    <div class="stat-item">
                        <span class="stat-number">${projects.length}</span>
                        <span class="stat-label">Projects</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-number">${completedTasks.length}/${allTasks.length}</span>
                        <span class="stat-label">Tasks Complete</span>
                    </div>
                </div>
                ${!compliance?.met && compliance?.comment ? `
                    <div class="compliance-comment">
                        <strong>Note:</strong> ${compliance.comment}
                    </div>
                ` : ''}
            `;
            
            // Add click handler to navigate to requirement detail
            card.addEventListener('click', () => {
                this.navigateTo('requirement', { 
                    domainId: domain.id, 
                    requirementId: reqId 
                });
            });
            
            grid.appendChild(card);
        });
    }





    // Utility functions
    generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }

    showError(message) {
        console.error(message);
        // Could implement a toast notification system here
        alert(message);
    }

    // Search functionality
    renderSearch() {
        const searchInput = document.getElementById('searchInput');
        const searchSubmit = document.getElementById('searchSubmit');
        const searchResults = document.getElementById('searchResults');
        
        const performSearch = () => {
            const query = searchInput.value.toLowerCase().trim();
            if (!query) {
                searchResults.innerHTML = '<p>Enter a search term to find projects, tasks, risks, or incidents.</p>';
                return;
            }
            
            const results = this.searchAll(query);
            this.renderSearchResults(results);
        };
        
        searchSubmit.addEventListener('click', performSearch);
        searchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                performSearch();
            }
        });
        
        // Initial state
        searchResults.innerHTML = '<p>Enter a search term to find projects, tasks, risks, or incidents.</p>';
    }

    searchAll(query) {
        const results = [];
        
        // Search domains
        this.domains.forEach(domain => {
            if (domain.title.toLowerCase().includes(query) || 
                domain.description.toLowerCase().includes(query)) {
                results.push({
                    type: 'domain',
                    item: domain,
                    domain: domain
                });
            }
        });
        
        // Search requirements
        Object.values(this.requirements).forEach(requirement => {
            if (requirement.title.toLowerCase().includes(query) || 
                requirement.description.toLowerCase().includes(query) ||
                requirement.guidance.toLowerCase().includes(query)) {
                const domain = this.domains.find(d => d.id === requirement.domainId);
                results.push({
                    type: 'requirement',
                    item: requirement,
                    domain: domain,
                    requirement: requirement
                });
            }
        });
        
        // Search projects
        this.projects.forEach(project => {
            if (project.name.toLowerCase().includes(query) || 
                project.description.toLowerCase().includes(query)) {
                results.push({
                    type: 'project',
                    item: project,
                    requirement: this.requirements[project.requirementId],
                    domain: this.domains.find(d => d.id === project.domainId)
                });
            }
        });
        
        // Search tasks
        this.tasks.forEach(task => {
            if (task.name.toLowerCase().includes(query) || 
                task.description.toLowerCase().includes(query)) {
                const project = this.projects.find(p => p.id === task.projectId);
                results.push({
                    type: 'task',
                    item: task,
                    project: project,
                    requirement: project ? this.requirements[project.requirementId] : null,
                    domain: project ? this.domains.find(d => d.id === project.domainId) : null
                });
            }
        });
        
        // Search risks
        this.risks.forEach(risk => {
            if (risk.name.toLowerCase().includes(query) || 
                risk.description.toLowerCase().includes(query) ||
                risk.mitigation.toLowerCase().includes(query)) {
                const project = this.projects.find(p => p.id === risk.projectId);
                results.push({
                    type: 'risk',
                    item: risk,
                    project: project,
                    requirement: project ? this.requirements[project.requirementId] : null,
                    domain: project ? this.domains.find(d => d.id === project.domainId) : null
                });
            }
        });
        
        // Search incidents
        this.incidents.forEach(incident => {
            if (incident.name.toLowerCase().includes(query) || 
                incident.description.toLowerCase().includes(query) ||
                incident.resolution.toLowerCase().includes(query)) {
                const project = this.projects.find(p => p.id === incident.projectId);
                results.push({
                    type: 'incident',
                    item: incident,
                    project: project,
                    requirement: project ? this.requirements[project.requirementId] : null,
                    domain: project ? this.domains.find(d => d.id === project.domainId) : null
                });
            }
        });
        
        return results;
    }

    renderSearchResults(results) {
        const searchResults = document.getElementById('searchResults');
        
        if (results.length === 0) {
            searchResults.innerHTML = '<p>No results found. Try a different search term or check your spelling.</p>';
            return;
        }
        
        searchResults.innerHTML = '';
        
        // Group results by type
        const groupedResults = {
            domain: [],
            requirement: [],
            project: [],
            task: [],
            risk: [],
            incident: []
        };
        
        results.forEach(result => {
            groupedResults[result.type].push(result);
        });
        
        // Render results by type
        Object.entries(groupedResults).forEach(([type, items]) => {
            if (items.length === 0) return;
            
            const section = document.createElement('div');
            section.className = 'search-section';
            section.innerHTML = `<h3 class="search-section-title">${type.charAt(0).toUpperCase() + type.slice(1)}s (${items.length})</h3>`;
            
            items.forEach(result => {
                const card = document.createElement('div');
                card.className = 'search-result-card';
                
                let contextPath = '';
                if (result.type === 'domain') {
                    contextPath = 'PSPF Domain';
                } else if (result.type === 'requirement') {
                    contextPath = result.domain ? `${result.domain.title}` : 'Unknown Domain';
                } else if (result.domain && result.requirement) {
                    contextPath = `${result.domain.title} → ${result.requirement.title}`;
                    if (result.project) {
                        contextPath += ` → ${result.project.name}`;
                    }
                }
                
                let description = result.item.description || '';
                if (result.type === 'risk' && result.item.mitigation) {
                    description += ` (Mitigation: ${result.item.mitigation})`;
                } else if (result.type === 'incident' && result.item.resolution) {
                    description += ` (Resolution: ${result.item.resolution})`;
                }
                
                card.innerHTML = `
                    <div class="result-header">
                        <span class="result-type">${result.type}</span>
                        <h4>${result.item.name || result.item.title}</h4>
                    </div>
                    <p class="result-description">${description}</p>
                    <div class="result-context">
                        <small>${contextPath}</small>
                    </div>
                `;
                
                card.addEventListener('click', () => {
                    this.navigateToSearchResult(result);
                });
                
                section.appendChild(card);
            });
            
            searchResults.appendChild(section);
        });
    }

    navigateToSearchResult(result) {
        switch (result.type) {
            case 'domain':
                this.showDomainRequirements(result.domain.id);
                this.navigateTo('home');
                this.updateNavButtons('homeBtn');
                break;
            case 'requirement':
                this.navigateTo('requirement', {
                    domainId: result.domain.id,
                    requirementId: result.requirement.id
                });
                break;
            case 'project':
                this.navigateTo('requirement', {
                    domainId: result.domain.id,
                    requirementId: result.requirement.id
                });
                break;
            case 'task':
            case 'risk':
            case 'incident':
                if (result.project) {
                    this.navigateTo('project', {
                        domainId: result.domain.id,
                        requirementId: result.requirement.id,
                        projectId: result.project.id
                    });
                }
                break;
        }
    }

    // Progress view
    renderProgress() {
        const progressGrid = document.getElementById('progressGrid');
        if (!progressGrid) {
            console.error('progressGrid element not found!');
            return;
        }
        
        progressGrid.innerHTML = '';
        
        // Remove any existing event listeners
        if (this.handleProgressClick) {
            progressGrid.removeEventListener('click', this.handleProgressClick);
        }
        
        this.domains.forEach((domain) => {
            const health = this.calculateDomainHealth(domain.id);
            const requirements = domain.requirements;
            const completedRequirements = requirements.filter(reqId => 
                this.compliance[reqId] && this.compliance[reqId].met
            ).length;
            const progressPercentage = Math.round((completedRequirements / requirements.length) * 100);
            
            const projects = this.projects.filter(p => domain.requirements.includes(p.requirementId));
            const completedProjects = projects.filter(p => p.status === 'completed').length;
            
            const card = document.createElement('div');
            card.className = 'progress-card';
            card.innerHTML = `
                <div class="progress-header">
                    <div class="pulse-dot ${health}"></div>
                    <h3>${domain.title}</h3>
                </div>
                <div class="progress-stats">
                    <div class="stat">
                        <span class="stat-number">${progressPercentage}%</span>
                        <span class="stat-label">Requirements Met</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">${completedProjects}/${projects.length}</span>
                        <span class="stat-label">Projects Complete</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">${completedRequirements}/${requirements.length}</span>
                        <span class="stat-label">Requirements</span>
                    </div>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${progressPercentage}%"></div>
                </div>
                <div class="progress-actions">
                    <button class="btn btn-secondary manage-compliance-btn" data-domain-id="${domain.id}">
                        Manage Compliance
                    </button>
                </div>
            `;
            
            progressGrid.appendChild(card);
        });
        
        // Add event delegation for manage compliance buttons
        this.handleProgressClick = (e) => {
            if (e.target.classList.contains('manage-compliance-btn')) {
                e.preventDefault();
                e.stopPropagation();
                const domainId = e.target.getAttribute('data-domain-id');
                this.showComplianceDetails(domainId);
            }
        };
        
        progressGrid.addEventListener('click', this.handleProgressClick);
    }

    showComplianceDetails(domainId) {
        const domain = this.domains.find(d => d.id === domainId);
        if (!domain) {
            console.error('Domain not found:', domainId);
            return;
        }
        
        // Create and show compliance management modal
        const modal = document.createElement('div');
        modal.className = 'modal active';  // Add 'active' class to make it visible
        
        try {
            modal.innerHTML = `
                <div class="modal-content compliance-modal">
                    <div class="modal-header">
                        <h2>Compliance Management - ${domain.title}</h2>
                        <span class="close">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div class="compliance-overview">
                            <div class="domain-status">
                                <div class="pulse-dot ${this.calculateDomainHealth(domain.id)}"></div>
                                <div class="status-info">
                                    <h3>${domain.title}</h3>
                                    <p>${domain.description}</p>
                                    <div class="progress-summary">
                                        ${domain.requirements.filter(reqId => this.compliance[reqId]?.met).length} of ${domain.requirements.length} requirements met
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="compliance-requirements">
                            ${domain.requirements.map(reqId => {
                                const req = this.requirements[reqId];
                                const compliance = this.compliance[reqId] || { met: false, comment: '', assessmentDate: '', reviewDate: '', owner: '', evidence: '', notes: '' };
                                return `
                                    <div class="requirement-detail-card ${compliance.met ? 'completed' : 'pending'}">
                                        <div class="requirement-header">
                                            <div class="requirement-info">
                                                <h4 class="requirement-title">${req.title}</h4>
                                                <p class="requirement-description">${req.description}</p>
                                            </div>
                                            <div class="compliance-status-section">
                                                <label class="compliance-toggle">
                                                    <input type="checkbox" ${compliance.met ? 'checked' : ''} 
                                                           data-requirement-id="${reqId}">
                                                    <span class="compliance-status-text">${compliance.met ? 'Compliant' : 'Not Compliant'}</span>
                                                </label>
                                            </div>
                                        </div>
                                        
                                        <div class="requirement-details">
                                            <div class="detail-row">
                                                <div class="detail-group">
                                                    <label>Assessment Date</label>
                                                    <input type="date" data-requirement-id="${reqId}" data-field="assessmentDate" 
                                                           value="${compliance.assessmentDate || ''}" class="form-control">
                                                </div>
                                                <div class="detail-group">
                                                    <label>Review Date</label>
                                                    <input type="date" data-requirement-id="${reqId}" data-field="reviewDate" 
                                                           value="${compliance.reviewDate || ''}" class="form-control">
                                                </div>
                                                <div class="detail-group">
                                                    <label>Owner/Responsible</label>
                                                    <input type="text" data-requirement-id="${reqId}" data-field="owner" 
                                                           value="${compliance.owner || ''}" placeholder="Enter responsible person" class="form-control">
                                                </div>
                                            </div>
                                            
                                            <div class="detail-row">
                                                <div class="detail-group full-width">
                                                    <label>Evidence/Documentation</label>
                                                    <textarea data-requirement-id="${reqId}" data-field="evidence" 
                                                              placeholder="Describe evidence of compliance, reference documents, etc." 
                                                              class="form-control" rows="2">${compliance.evidence || ''}</textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="detail-row">
                                                <div class="detail-group full-width">
                                                    <label>${compliance.met ? 'Additional Notes' : 'Non-Compliance Details & Remediation Plan'}</label>
                                                    <textarea data-requirement-id="${reqId}" data-field="comment" 
                                                              placeholder="${compliance.met ? 'Add any additional notes or observations' : 'Explain why this requirement is not met and what steps are planned to achieve compliance'}" 
                                                              class="form-control" rows="3">${compliance.comment || ''}</textarea>
                                                </div>
                                            </div>
                                            
                                            <div class="detail-row">
                                                <div class="detail-group full-width">
                                                    <label>Implementation Notes</label>
                                                    <textarea data-requirement-id="${reqId}" data-field="notes" 
                                                              placeholder="Internal notes, implementation details, lessons learned, etc." 
                                                              class="form-control" rows="2">${compliance.notes || ''}</textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                    <div class="modal-footer">
                        <div class="footer-info">
                            <small>All changes are automatically saved</small>
                        </div>
                        <div class="footer-actions">
                            <button class="btn btn-secondary close-modal">Close</button>
                        </div>
                    </div>
                </div>
            `;
        } catch (error) {
            console.error('Error setting modal innerHTML:', error);
            return;
        }
        
        document.body.appendChild(modal);
        
        // Add event listeners
        try {
            const closeBtn = modal.querySelector('.close');
            const closeModalBtn = modal.querySelector('.close-modal');
            
            // Close button handlers
            if (closeBtn) {
                closeBtn.addEventListener('click', () => modal.remove());
            }
            
            if (closeModalBtn) {
                closeModalBtn.addEventListener('click', () => modal.remove());
            }
            
            // Handle compliance checkbox changes
            modal.addEventListener('change', (e) => {
                if (e.target.type === 'checkbox' && e.target.dataset.requirementId) {
                    const reqId = e.target.dataset.requirementId;
                    const isCompliant = e.target.checked;
                    
                    if (!this.compliance[reqId]) {
                        this.compliance[reqId] = {};
                    }
                    
                    this.compliance[reqId].met = isCompliant;
                    this.saveData();
                    
                    // Update the status text
                    const statusText = e.target.nextElementSibling;
                    statusText.textContent = isCompliant ? 'Compliant' : 'Not Compliant';
                    
                    // Update the card styling
                    const card = e.target.closest('.requirement-detail-card');
                    card.className = `requirement-detail-card ${isCompliant ? 'completed' : 'pending'}`;
                    
                    // Update placeholder text for comments
                    const commentTextarea = card.querySelector('textarea[data-field="comment"]');
                    if (commentTextarea) {
                        const commentLabel = card.querySelector('textarea[data-field="comment"]').previousElementSibling;
                        commentLabel.textContent = isCompliant ? 'Additional Notes' : 'Non-Compliance Details & Remediation Plan';
                        commentTextarea.placeholder = isCompliant ? 
                            'Add any additional notes or observations' : 
                            'Explain why this requirement is not met and what steps are planned to achieve compliance';
                    }
                    
                    // Update domain grid and progress view
                    this.renderProgress();
                    this.renderDomainsGrid();
                }
            });

            // Handle input changes for all compliance fields
            modal.addEventListener('input', (e) => {
                if (e.target.dataset.requirementId && e.target.dataset.field) {
                    const reqId = e.target.dataset.requirementId;
                    const field = e.target.dataset.field;
                    
                    if (!this.compliance[reqId]) {
                        this.compliance[reqId] = {};
                    }
                    
                    this.compliance[reqId][field] = e.target.value;
                    this.saveData();
                }
            });
            
            // Handle blur events to save changes immediately
            modal.addEventListener('blur', (e) => {
                if (e.target.dataset.requirementId && e.target.dataset.field) {
                    this.saveData();
                }
            }, true);
        } catch (error) {
            console.error('Error setting up event listeners:', error);
        }
        
        // Add click outside to close
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        });
    }

    updateComplianceFromProgress(requirementId, met) {
        if (!this.compliance[requirementId]) {
            this.compliance[requirementId] = {};
        }
        this.compliance[requirementId].met = met;
        this.saveData();
        this.renderProgress(); // Re-render to update UI
        this.renderDomainsGrid(); // Update domain health indicators
    }



    // Project view placeholder
    renderProject() {
        const project = this.projects.find(p => p.id === this.currentProject);
        if (!project) return;
        
        document.getElementById('projectTitle').textContent = project.name;
        document.getElementById('projectDescription').textContent = project.description;
        document.getElementById('projectStatus').textContent = project.status;
        document.getElementById('projectStatus').className = `status-badge ${project.status}`;
        
        const startDate = project.startDate ? new Date(project.startDate).toLocaleDateString() : 'Not set';
        const endDate = project.endDate ? new Date(project.endDate).toLocaleDateString() : 'Not set';
        document.getElementById('projectDates').textContent = `${startDate} - ${endDate}`;
        
        // Handle project URL
        const projectUrlElement = document.getElementById('projectUrl');
        if (project.url) {
            projectUrlElement.classList.remove('hidden');
            projectUrlElement.querySelector('a').href = project.url;
        } else {
            projectUrlElement.classList.add('hidden');
        }
        
        this.renderTasksList();
        this.renderRisksList();
        this.renderIncidentsList();
    }

    // CRUD Operations - Projects
    showProjectModal(projectId = null) {
        this.currentEditingProject = projectId;
        const modal = document.getElementById('projectModal');
        const title = document.getElementById('projectModalTitle');
        const form = document.getElementById('projectForm');
        
        if (projectId) {
            const project = this.projects.find(p => p.id === projectId);
            title.textContent = 'Edit Project';
            this.populateProjectForm(project);
        } else {
            title.textContent = 'Add Project';
            form.reset();
        }
        
        modal.classList.add('active');
    }

    populateProjectForm(project) {
        document.getElementById('projectName').value = project.name;
        document.getElementById('projectDesc').value = project.description;
        document.getElementById('projectStatusSelect').value = project.status;
        document.getElementById('projectStartDate').value = project.startDate;
        document.getElementById('projectEndDate').value = project.endDate;
        document.getElementById('projectUrl').value = project.url || '';
    }

    handleProjectSubmit(e) {
        e.preventDefault();
        
        const projectData = {
            name: document.getElementById('projectName').value,
            description: document.getElementById('projectDesc').value,
            status: document.getElementById('projectStatusSelect').value,
            startDate: document.getElementById('projectStartDate').value,
            endDate: document.getElementById('projectEndDate').value,
            url: document.getElementById('projectUrl').value,
            requirementId: this.currentRequirement,
            domainId: this.currentDomain
        };

        if (this.currentEditingProject) {
            this.updateProject(this.currentEditingProject, projectData);
        } else {
            this.createProject(projectData);
        }

        this.hideModal('projectModal');
        this.render(); // Re-render current view
    }

    createProject(projectData) {
        const project = {
            id: this.generateId(),
            ...projectData,
            createdAt: new Date().toISOString()
        };
        
        this.projects.push(project);
        this.saveData();
    }

    updateProject(projectId, projectData) {
        const index = this.projects.findIndex(p => p.id === projectId);
        if (index !== -1) {
            this.projects[index] = { ...this.projects[index], ...projectData };
            this.saveData();
        }
    }

    deleteProject(projectId) {
        if (confirm('Are you sure you want to delete this project? This will also delete all associated tasks, risks, and incidents.')) {
            // Remove project
            this.projects = this.projects.filter(p => p.id !== projectId);
            
            // Remove associated tasks, risks, and incidents
            this.tasks = this.tasks.filter(t => t.projectId !== projectId);
            this.risks = this.risks.filter(r => r.projectId !== projectId);
            this.incidents = this.incidents.filter(i => i.projectId !== projectId);
            
            this.saveData();
            this.render();
        }
    }

    // CRUD Operations - Tasks
    showTaskModal(taskId = null) {
        this.currentEditingTask = taskId;
        const modal = document.getElementById('taskModal');
        const title = document.getElementById('taskModalTitle');
        const form = document.getElementById('taskForm');
        
        if (taskId) {
            const task = this.tasks.find(t => t.id === taskId);
            title.textContent = 'Edit Task';
            this.populateTaskForm(task);
        } else {
            title.textContent = 'Add Task';
            form.reset();
        }
        
        modal.classList.add('active');
    }

    populateTaskForm(task) {
        document.getElementById('taskName').value = task.name;
        document.getElementById('taskDesc').value = task.description;
        document.getElementById('taskStatus').value = task.status;
        document.getElementById('taskAssignee').value = task.assignee;
        document.getElementById('taskDueDate').value = task.dueDate;
    }

    handleTaskSubmit(e) {
        e.preventDefault();
        
        const taskData = {
            name: document.getElementById('taskName').value,
            description: document.getElementById('taskDesc').value,
            status: document.getElementById('taskStatus').value,
            assignee: document.getElementById('taskAssignee').value,
            dueDate: document.getElementById('taskDueDate').value,
            projectId: this.currentProject
        };

        if (this.currentEditingTask) {
            this.updateTask(this.currentEditingTask, taskData);
        } else {
            this.createTask(taskData);
        }

        this.hideModal('taskModal');
        this.render();
    }

    createTask(taskData) {
        const task = {
            id: this.generateId(),
            ...taskData,
            createdAt: new Date().toISOString()
        };
        
        this.tasks.push(task);
        this.saveData();
    }

    updateTask(taskId, taskData) {
        const index = this.tasks.findIndex(t => t.id === taskId);
        if (index !== -1) {
            this.tasks[index] = { ...this.tasks[index], ...taskData };
            this.saveData();
        }
    }

    deleteTask(taskId) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id !== taskId);
            this.saveData();
            this.render();
        }
    }

    // CRUD Operations - Risks
    showRiskModal(riskId = null) {
        this.currentEditingRisk = riskId;
        const modal = document.getElementById('riskModal');
        const title = document.getElementById('riskModalTitle');
        const form = document.getElementById('riskForm');
        
        if (riskId) {
            const risk = this.risks.find(r => r.id === riskId);
            title.textContent = 'Edit Risk';
            this.populateRiskForm(risk);
        } else {
            title.textContent = 'Add Risk';
            form.reset();
        }
        
        modal.classList.add('active');
    }

    populateRiskForm(risk) {
        document.getElementById('riskName').value = risk.name;
        document.getElementById('riskDesc').value = risk.description;
        document.getElementById('riskLikelihood').value = risk.likelihood;
        document.getElementById('riskImpact').value = risk.impact;
        document.getElementById('riskMitigation').value = risk.mitigation;
    }

    handleRiskSubmit(e) {
        e.preventDefault();
        
        const riskData = {
            name: document.getElementById('riskName').value,
            description: document.getElementById('riskDesc').value,
            likelihood: document.getElementById('riskLikelihood').value,
            impact: document.getElementById('riskImpact').value,
            mitigation: document.getElementById('riskMitigation').value,
            projectId: this.currentProject
        };

        if (this.currentEditingRisk) {
            this.updateRisk(this.currentEditingRisk, riskData);
        } else {
            this.createRisk(riskData);
        }

        this.hideModal('riskModal');
        this.render();
    }

    createRisk(riskData) {
        const risk = {
            id: this.generateId(),
            ...riskData,
            createdAt: new Date().toISOString()
        };
        
        this.risks.push(risk);
        this.saveData();
    }

    updateRisk(riskId, riskData) {
        const index = this.risks.findIndex(r => r.id === riskId);
        if (index !== -1) {
            this.risks[index] = { ...this.risks[index], ...riskData };
            this.saveData();
        }
    }

    deleteRisk(riskId) {
        if (confirm('Are you sure you want to delete this risk?')) {
            this.risks = this.risks.filter(r => r.id !== riskId);
            this.saveData();
            this.render();
        }
    }

    // CRUD Operations - Incidents
    showIncidentModal(incidentId = null) {
        this.currentEditingIncident = incidentId;
        const modal = document.getElementById('incidentModal');
        const title = document.getElementById('incidentModalTitle');
        const form = document.getElementById('incidentForm');
        
        if (incidentId) {
            const incident = this.incidents.find(i => i.id === incidentId);
            title.textContent = 'Edit Incident';
            this.populateIncidentForm(incident);
        } else {
            title.textContent = 'Add Incident';
            form.reset();
            // Set default date to now
            document.getElementById('incidentDate').value = new Date().toISOString().slice(0, 16);
        }
        
        modal.classList.add('active');
    }

    populateIncidentForm(incident) {
        document.getElementById('incidentName').value = incident.name;
        document.getElementById('incidentDesc').value = incident.description;
        document.getElementById('incidentDate').value = incident.date;
        document.getElementById('incidentSeverity').value = incident.severity;
        document.getElementById('incidentResolution').value = incident.resolution;
    }

    handleIncidentSubmit(e) {
        e.preventDefault();
        
        const incidentData = {
            name: document.getElementById('incidentName').value,
            description: document.getElementById('incidentDesc').value,
            date: document.getElementById('incidentDate').value,
            severity: document.getElementById('incidentSeverity').value,
            resolution: document.getElementById('incidentResolution').value,
            projectId: this.currentProject
        };

        if (this.currentEditingIncident) {
            this.updateIncident(this.currentEditingIncident, incidentData);
        } else {
            this.createIncident(incidentData);
        }

        this.hideModal('incidentModal');
        this.render();
    }

    createIncident(incidentData) {
        const incident = {
            id: this.generateId(),
            ...incidentData,
            createdAt: new Date().toISOString()
        };
        
        this.incidents.push(incident);
        this.saveData();
    }

    updateIncident(incidentId, incidentData) {
        const index = this.incidents.findIndex(i => i.id === incidentId);
        if (index !== -1) {
            this.incidents[index] = { ...this.incidents[index], ...incidentData };
            this.saveData();
        }
    }

    deleteIncident(incidentId) {
        if (confirm('Are you sure you want to delete this incident?')) {
            this.incidents = this.incidents.filter(i => i.id !== incidentId);
            this.saveData();
            this.render();
        }
    }

    // List Rendering Functions
    renderTasksList() {
        const list = document.getElementById('tasksList');
        const tasks = this.tasks.filter(t => t.projectId === this.currentProject);
        
        list.innerHTML = '';
        
        if (tasks.length === 0) {
            list.innerHTML = '<p>No tasks yet. Add a task to start tracking work.</p>';
        } else {
            tasks.forEach(task => {
                const card = document.createElement('div');
                card.className = 'list-item';
                card.innerHTML = `
                    <div class="list-item-header">
                        <h5 class="list-item-title">${task.name}</h5>
                        <div class="list-item-actions">
                            <button class="btn btn-secondary" data-action="edit-task" data-id="${task.id}">Edit</button>
                            <button class="btn btn-secondary" data-action="delete-task" data-id="${task.id}">Delete</button>
                        </div>
                    </div>
                    <p>${task.description}</p>
                    <div class="list-item-meta">
                        <span class="status-badge ${task.status}">${task.status}</span>
                        <span>Assignee: ${task.assignee || 'Unassigned'}</span>
                        <span>Due: ${task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'Not set'}</span>
                    </div>
                `;
                list.appendChild(card);
            });
        }
    }

    renderRisksList() {
        const list = document.getElementById('risksList');
        const risks = this.risks.filter(r => r.projectId === this.currentProject);
        
        list.innerHTML = '';
        
        if (risks.length === 0) {
            list.innerHTML = '<p>No risks identified yet. Add risks to track potential issues.</p>';
        } else {
            risks.forEach(risk => {
                const riskLevel = this.calculateRiskLevel(risk.likelihood, risk.impact);
                const card = document.createElement('div');
                card.className = 'list-item';
                card.innerHTML = `
                    <div class="list-item-header">
                        <h5 class="list-item-title">${risk.name}</h5>
                        <div class="list-item-actions">
                            <button class="btn btn-secondary" data-action="edit-risk" data-id="${risk.id}">Edit</button>
                            <button class="btn btn-secondary" data-action="delete-risk" data-id="${risk.id}">Delete</button>
                        </div>
                    </div>
                    <p>${risk.description}</p>
                    <div class="list-item-meta">
                        <span class="status-badge ${riskLevel.toLowerCase()}">${riskLevel} Risk</span>
                        <span>Likelihood: ${risk.likelihood}</span>
                        <span>Impact: ${risk.impact}</span>
                    </div>
                    ${risk.mitigation ? `<div class="mitigation"><strong>Mitigation:</strong> ${risk.mitigation}</div>` : ''}
                `;
                list.appendChild(card);
            });
        }
    }

    renderIncidentsList() {
        const list = document.getElementById('incidentsList');
        const incidents = this.incidents.filter(i => i.projectId === this.currentProject);
        
        list.innerHTML = '';
        
        if (incidents.length === 0) {
            list.innerHTML = '<p>No incidents recorded yet. Add incidents to track issues that have occurred.</p>';
        } else {
            incidents.forEach(incident => {
                const card = document.createElement('div');
                card.className = 'list-item';
                card.innerHTML = `
                    <div class="list-item-header">
                        <h5 class="list-item-title">${incident.name}</h5>
                        <div class="list-item-actions">
                            <button class="btn btn-secondary" data-action="edit-incident" data-id="${incident.id}">Edit</button>
                            <button class="btn btn-secondary" data-action="delete-incident" data-id="${incident.id}">Delete</button>
                        </div>
                    </div>
                    <p>${incident.description}</p>
                    <div class="list-item-meta">
                        <span class="status-badge ${incident.severity}">${incident.severity}</span>
                        <span>Date: ${new Date(incident.date).toLocaleDateString()}</span>
                    </div>
                    ${incident.resolution ? `<div class="resolution"><strong>Resolution:</strong> ${incident.resolution}</div>` : ''}
                `;
                list.appendChild(card);
            });
        }
    }

    calculateRiskLevel(likelihood, impact) {
        const levels = { 'very-low': 1, 'low': 2, 'medium': 3, 'high': 4, 'very-high': 5 };
        const score = levels[likelihood] * levels[impact];
        
        if (score >= 20) return 'Critical';
        if (score >= 12) return 'High';
        if (score >= 6) return 'Medium';
        return 'Low';
    }

    // Modal Management
    hideModal(modalId) {
        const modal = document.getElementById(modalId);
        modal.classList.remove('active');
    }

    // Data Management functionality
    renderDataManagement() {
        this.updateDataStats();
    }

    updateDataStats() {
        document.getElementById('dataProjectCount').textContent = this.projects.length;
        document.getElementById('dataTaskCount').textContent = this.tasks.length;
        document.getElementById('dataRiskCount').textContent = this.risks.length;
        document.getElementById('dataIncidentCount').textContent = this.incidents.length;
        
        // Get last modified date from localStorage
        const lastModified = localStorage.getItem('pspf_last_modified');
        if (lastModified) {
            const date = new Date(lastModified);
            document.getElementById('dataLastModified').textContent = date.toLocaleString();
        } else {
            document.getElementById('dataLastModified').textContent = 'Never';
        }
    }

    exportData() {
        try {
            // Gather all data
            const exportData = {
                version: '1.0',
                exportDate: new Date().toISOString(),
                data: {
                    projects: this.projects,
                    tasks: this.tasks,
                    risks: this.risks,
                    incidents: this.incidents,
                    compliance: JSON.parse(localStorage.getItem('pspf_compliance') || '{}')
                }
            };

            // Create downloadable file
            const dataStr = JSON.stringify(exportData, null, 2);
            const dataBlob = new Blob([dataStr], { type: 'application/json' });
            
            // Create download link
            const downloadLink = document.createElement('a');
            downloadLink.href = URL.createObjectURL(dataBlob);
            downloadLink.download = `pspf-explorer-backup-${new Date().toISOString().slice(0, 19).replace(/[:.]/g, '-')}.json`;
            
            // Trigger download
            document.body.appendChild(downloadLink);
            downloadLink.click();
            document.body.removeChild(downloadLink);
            
            this.showMessage('Data exported successfully! Check your downloads folder.');
            
        } catch (error) {
            console.error('Export failed:', error);
            this.showMessage('Export failed. Please try again.');
        }
    }

    importData(event) {
        const file = event.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const importData = JSON.parse(e.target.result);
                
                // Validate data structure
                if (!importData.data || !importData.version) {
                    throw new Error('Invalid backup file format');
                }

                // Confirm import
                const confirmMessage = `This will replace all current data with imported data.\n\nImported data contains:\n• ${importData.data.projects?.length || 0} projects\n• ${importData.data.tasks?.length || 0} tasks\n• ${importData.data.risks?.length || 0} risks\n• ${importData.data.incidents?.length || 0} incidents\n\nContinue?`;
                
                if (!confirm(confirmMessage)) {
                    return;
                }

                // Import data
                this.projects = importData.data.projects || [];
                this.tasks = importData.data.tasks || [];
                this.risks = importData.data.risks || [];
                this.incidents = importData.data.incidents || [];

                // Save to localStorage
                this.saveData();
                
                // Import compliance data if available
                if (importData.data.compliance) {
                    localStorage.setItem('pspf_compliance', JSON.stringify(importData.data.compliance));
                }

                // Update last modified
                localStorage.setItem('pspf_last_modified', new Date().toISOString());

                // Refresh current view
                this.updateDataStats();
                this.renderHome();

                this.showMessage('Data imported successfully!');
                
            } catch (error) {
                console.error('Import failed:', error);
                this.showMessage('Import failed. Please check the file format and try again.');
            }
        };

        reader.readAsText(file);
        
        // Reset file input
        event.target.value = '';
    }

    clearAllData() {
        const confirmMessage = 'This will permanently delete ALL your data including:\n• All projects\n• All tasks\n• All risks\n• All incidents\n• All compliance settings\n\nThis action cannot be undone!\n\nAre you sure?';
        
        if (!confirm(confirmMessage)) {
            return;
        }

        const doubleConfirm = 'Final confirmation: Type "DELETE" to proceed with clearing all data:';
        const userInput = prompt(doubleConfirm);
        
        if (userInput !== 'DELETE') {
            this.showMessage('Data clearing cancelled.');
            return;
        }

        try {
            // Clear all data arrays
            this.projects = [];
            this.tasks = [];
            this.risks = [];
            this.incidents = [];

            // Clear localStorage
            localStorage.removeItem('pspf_projects');
            localStorage.removeItem('pspf_tasks');
            localStorage.removeItem('pspf_risks');
            localStorage.removeItem('pspf_incidents');
            localStorage.removeItem('pspf_compliance');
            localStorage.removeItem('pspf_last_modified');

            // Refresh views
            this.updateDataStats();
            this.renderHome();

            this.showMessage('All data has been cleared successfully.');
            
        } catch (error) {
            console.error('Clear data failed:', error);
            this.showMessage('Failed to clear data. Please try again.');
        }
    }

    saveData() {
        localStorage.setItem('pspf_projects', JSON.stringify(this.projects));
        localStorage.setItem('pspf_tasks', JSON.stringify(this.tasks));
        localStorage.setItem('pspf_risks', JSON.stringify(this.risks));
        localStorage.setItem('pspf_incidents', JSON.stringify(this.incidents));
        localStorage.setItem('pspf_last_modified', new Date().toISOString());
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.pspfExplorer = new PSPFExplorer();
});